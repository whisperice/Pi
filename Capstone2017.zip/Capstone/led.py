import RPi.GPIO as GPIO
import time

LED = 21

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)

while True:
    GPIO.output(LED, GPIO.HIGH)
    time.sleep(0.005)
    GPIO.output(LED, GPIO.LOW)
    time.sleep(0.5)
