import serial
import RPi.GPIO as GPIO

LED = 21
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)
GPIO.output(LED, GPIO.LOW)
#threshold and pulseTime need to be proper value to make blinds separated
pulsethreshold=900 #Led blind every 900J
pulseEnergy=0 #record the energy make Led blink
pulseLoop=10 #max time length 200ms(about 20ms per whlie loop) for Led pulse
cnt=0 #count for pulse time

ser = serial.Serial ("/dev/ttyS0")    #Open named port 
ser.baudrate = 76800                     #Set baud rate to 76800
volt=[0 for i in range(0,20)]
curr=[0 for i in range(0,20)]
timeT=[0 for i in range(0,20)]
timeAxis=[]
voltAxis=[]
currAxis=[]
numPoint=20
RI=7.5
CTR=2500.0
RVL=1600.0
RVH=1200000.0
totalEnergy=0
groupIndex=0
voltOffset = 0.55413806
currOffset = 0.186867
voltScale = 0.9958
currScale = 1.0347
voltScaleOffset = 0.3092
currScaleOffset = -0.0149
totalTime=0
totalEnergy=0
lastTime=0
LCDPower=0
LCDEnergy=0

f = open('data.txt','w')
fenergy = open('energy.txt','w')

f.write('volt/V\t\t\tcurr/A\t\t\ttotaltime/us\n')
fenergy.write('energy/J\t\ttotalEnergy/J\n')

print('Measuring...')

while True:
	power=0
	energy=0
	period=0

	for i in range(0,numPoint):
		data = ser.read(6)                  #Read 6 characters from serial
		'''
		for raw in data:
			print(bin(raw))
		'''
		volt[i] = data[1]*2**8+ data[0] 
		if volt[i] > 2**15:
			volt[i] -= 2**16
		#volt[i] = volt[i]/32767.0*600.0
		volt[i] = ((volt[i]/32767.0*600.0)/RVL*(RVH+RVL)/1000 + voltOffset)*voltScale + voltScaleOffset
		#print('volt= '+str(volt[i])+' V')

		curr[i] = data[3]*2**8 + data[2] + currOffset
		if curr[i] > 2**15:
			curr[i] -= 2**16
		#curr[i]= curr[i]/32767.0*600.0
		#curr[i]= (curr[i]/32767.0*600.0)/RI*CTR/1000
		curr[i]= ((curr[i]/32767.0*600.0)/RI*CTR/1000 + currOffset)*currScale + currScaleOffset 
		#print('curr= '+str(curr[i])+' A')
		
		timeT[i] = data[5]*2**8 + data[4]
		#print('time= '+str(time[i])+' us')

		if len(timeAxis)==0:
			timeAxis.append(timeT[i])
		else:
                        timeAxis.append(timeAxis[-1]+timeT[i])                    
		#print('timeAxis= '+str(timeAxis[-1])+' us')
		
		power += volt[i]*curr[i]
		period += timeT[i]

	for i in range(0,numPoint):
                voltAxis.append(volt[i])
                currAxis.append(curr[i])
	if len(voltAxis)>100:
                del voltAxis[0:20]
                del currAxis[0:20]
                del timeAxis[0:20]

	#electricity calculation
	energy = power/numPoint*(period/10**6)
	#print('energy in the last period ='+str(energy)+' J')	
	totalEnergy += energy
	#print('totalEnergy= '+str(totalEnergy)+' J')
	totalTime += period

	if totalTime-lastTime>=1000000:
	      lastTime=totalTime
	      LCDPower=round(power/numPoint,2)
	      LCDEnergy=round(totalEnergy,2)
	      #lcd_string('Power:{}W'.format(LCDPower),LCD_LINE_1)
	      print('Power:{}W'.format(LCDPower))
	      if LCDEnergy>1000:
                LCDEnergy/=1000
                if LCDEnergy>3600:
                  LCDEnergy/=3600
                  #lcd_string('Energy:{}KWh'.format(round(LCDEnergy,2)),LCD_LINE_2)
                  print('Energy:{}KWh'.format(round(LCDEnergy,2)))
                else:
                  #lcd_string('Energy:{}KJ'.format(round(LCDEnergy,2)),LCD_LINE_2)
                  print('Energy:{}KJ'.format(round(LCDEnergy,2)))
	      else:              
                #lcd_string('Energy:{}J'.format(LCDEnergy),LCD_LINE_2)
                print('Energy:{}J'.format(LCDEnergy))
	      print('Measuring...')
   

        #set Led
	pulseEnergy += energy
	cnt += 1
	if pulseEnergy >= pulsethreshold:
                GPIO.output(LED, GPIO.HIGH)  #light on
                pulseEnergy -= pulsethreshold
                cnt=0
	if cnt == pulseLoop:
                GPIO.output(LED, GPIO.LOW) #light off
	
	#record datas
	for i in range(0,numPoint):
		f.write(str(volt[i])+'\t'+str(curr[i])+'\t'+str(timeAxis[-(20-i)])+'\n')
	fenergy.write(str(energy)+'\t'+str(totalEnergy)+'\n')
	f.flush
	fenergy.flush

f.close()
fenergy.close()
ser.close()



