import serial
import matplotlib.pyplot as plt

ser = serial.Serial ("/dev/ttyS0")    #Open named port 
ser.baudrate = 76800                     #Set baud rate to 76800
volt=[0 for i in range(0,20)]
curr=[0 for i in range(0,20)]
time=[0 for i in range(0,20)]
numPoint=20
totalEnergy=0
i=0

while True:
    for i in range(0,20):
            data = ser.read(2)                  #Read 6 characters from serial
		
            for raw in data:
                print(bin(raw))
		
            volt[i] = data[1]*2**8 + data[0]
            if volt[i] > 2**15:
                volt[i] -= 2**16
            volt[i] = volt[i]/32767.0*600.0
            volt[i] = volt[i]/1600.0*(1200000+1600)/1000
            #print('volt= '+str(volt[i])+' V')
            print(str(volt[i])+' V')

    plt.plot(volt)
    plt.show()

		


	
ser.close()



