import numpy as np
import matplotlib.pyplot as plt

fs=200.0
f0=0.1
Q=30.0
w0=f0/(fs/2)
b,a =signal.iirnotch(w0,Q)
x=3*sin2*pi*50+5
y=signal.lfilter(b,a,x)
plt.plot(y)
plt.show()
