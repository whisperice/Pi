from pylab import *
import time

volt=[i for i in range(0,20)]
curr=[i for i in range(20,40)]


plot(volt,curr)
show(block=False)
time.sleep(3)
close('all')
plot(curr,volt)
show(block=False)
time.sleep(3)
